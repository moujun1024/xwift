#ifndef XWIFT_CODEGEN_CODEGEN_H
#define XWIFT_CODEGEN_CODEGEN_H

#include "xwift/Basic/LLVM.h"

namespace xwift {

class CodeGen {
public:
  CodeGen() = default;
};

}

#endif
