#include "xwift/stdlib/Filesystem/Path.h"
#include <iostream>

namespace xwift {

// Helper function for XWift interpreter integration
extern "C" void* createPathValue(const char* path);

}