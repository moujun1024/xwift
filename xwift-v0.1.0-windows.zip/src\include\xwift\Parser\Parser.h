#ifndef XWIFT_PARSER_PARSER_H
#define XWIFT_PARSER_PARSER_H

#include "xwift/Basic/LLVM.h"

namespace xwift {

class Parser {
public:
  Parser() = default;
};

void testLexer(const std::string& source);

}

#endif
