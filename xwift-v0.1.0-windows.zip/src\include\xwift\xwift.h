#ifndef XWIFT_XWIFT_H
#define XWIFT_XWIFT_H

#include "xwift/Basic/LLVM.h"
#include "xwift/Basic/Version.h"

#endif
