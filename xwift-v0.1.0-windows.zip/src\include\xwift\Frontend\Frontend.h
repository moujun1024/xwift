#ifndef XWIFT_FRONTEND_FRONTEND_H
#define XWIFT_FRONTEND_FRONTEND_H

#include "xwift/Basic/LLVM.h"

namespace xwift {

class Frontend {
public:
  Frontend() = default;
};

}

#endif
