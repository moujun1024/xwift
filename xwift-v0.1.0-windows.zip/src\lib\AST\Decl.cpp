#include "xwift/AST/Decl.h"

namespace xwift {

}
